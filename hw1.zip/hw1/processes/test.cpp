#include<iostream>
#include<vector>
using namespace std;

// test
void someFunction();

int main(){

		int a = 2;
		std::vector<std::string> vectors;

		return 0;

}
